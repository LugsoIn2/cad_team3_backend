from django.apps import AppConfig


class FileAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'file_app'
